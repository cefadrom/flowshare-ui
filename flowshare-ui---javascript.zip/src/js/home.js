$(function () {

    // ---------- GLOBAL FUNCTIONS ----------

    $(window).resize(function () {

        let windowWidth = $(window).width();
        // let windowHeight = $(window).height();

        searchBarWindowResize();

        filterWindowResize();

        flowDataWindowResize(windowWidth);

    });

    let body = $('body');
    const flowshareURLs = {
        homepage: 'https://rasphost.com/flowshare/web/test/home',
        homepageDir: '/flowshare/web/test/home/',
        api: 'https://rasphost.com/flowshare/'
    };


    // ---------- CHECKING ACCOUNT ----------

    let account = Cookies.getJSON('account'),
        accountPopup = $('#header-account-popup'),
        headerAccountUser = $('#header-account-user');

    if (account && account['token']) {

        headerAccountUser.text('Connecting...');

        $.ajax({
            method: 'GET',
            url: flowshareURLs.api + 'account.php',
            data: {
                token: account['token']
            },
            success: function (data) {

                try {
                    data = JSON.parse(data)
                } catch (e) {
                    console.error(e)
                }

                if (data['error']) {
                    headerAccountUser.text('Account');
                    toggleAccountPopup(true, data['error'], '#ff5b5f');
                    setTimeout(toggleAccountPopup, 8000, false);

                    if (!Cookies.getJSON('account')['email']) Cookies.remove('account');

                }

                headerAccountUser.text(data['username']);


            },
            error: function () {
                toggleAccountPopup(true, 'AJAX error', '#ff5b5f');
                setTimeout(toggleAccountPopup, 8000, false);
            }
        })

    }

    accountPopup.on('click.flowshare', function () {
        toggleAccountPopup(false);
    });

    function toggleAccountPopup(state, message, color) {

        if (!state) {
            return accountPopup.fadeOut();
        }

        accountPopup
            .text(message)
            .css('backgroundColor', color)
            .fadeIn();

    }


    // ---------- SEARCH BAR RESIZING ----------

    let allowSearchBarResize = $(window).width() < 750;
    let resultContainer = $('#search-results');

    function searchBarWindowResize() {
        allowSearchBarResize = $(window).width() < 750;
    }

    $('#search-box').hover(
        function () {
            searchBarResize(true);
        },
        function () {
            searchBarResize(false)
        }
    );

    function searchBarResize(showFull, force) { // manage search bar on mobile (takes entire screen when focused)

        if (!allowSearchBarResize && !force) return;    // if can't be resized (screen is too big)

        if (showFull) { // full search bar

            $('#logo-big, #header-account').fadeOut(400);   // makes logo and account disappear
            $('#search-box').css({  // expand global div
                width: '280px',
                right: 'calc((100% - 280px) / 2)'
            });
            $('#search-txt').css('width', '230px'); // expand search field
            resultContainer.show(); // shows results

            setTimeout(function () {
                $('#search-txt')
                    .focus()[0] // put focus on search field
                    .setSelectionRange(999999, 999999); // put cursor at the end of the text+
            }, 100);

        } else {    // close search bar

            $('#logo-big, #header-account').fadeIn(400);    // makes logo and account appear
            $('#search-box')
                .css({  // collapse global div
                    width: 'auto',
                    right: '120px'
                })
                .blur();    // remove the focus
            $('#search-txt').css('width', '0');     // collapse search field
            resultContainer.hide(); // hide results

        }
    }

    // ---------- SEARCH FUNCTION ----------

    let searchResultData;   // array with result flows from search

    $('#search-txt').on('blur', function () {   // remove instant search on text blur
        setTimeout(     // timeout because if it's disappear too fast the user can't click on the search results
            function () {
                searchBarResize(false);
                resultContainer
                    .css('padding', '0')
                    .html('');
            },
            100
        )

    });


    // ----- INSTANT SEARCH -----

    $('#search-txt').on('keyup focus', function () {    // trigger instant search

        let searchStr = $(this).val();  // text entered in the search field

        if (searchStr.match(/^[ ]*$/))  // if field is blank
            return resultContainer
                .css('padding', '0')
                .html('');

        instantSearch(searchStr);

    });

    function instantSearch(str) {

        if (str.length > 31) return displayResult('Text is too long', true);

        $.ajax({
            method: 'GET',
            url: flowshareURLs.api + 'search.php?instant&text=' + encodeURI(str),
            timeout: 2000,
            success: function (data) {

                try {
                    data = JSON.parse(data)
                } catch (e) {
                    return displayResult('JSON parse error', true);
                }

                if (data.error) return displayResult(data.error, true);

                searchResultData = data;
                displayResult(data);

            },
            error: function () {
                displayResult('AJAX error', true);
            }
        });

        // Format result

        function displayResult(data, error) {

            if ($('#search-txt').val() !== str) return;

            resultContainer
                .css('padding', '8px')
                .html('');

            if (error) return resultContainer.append(
                $('<div class="result" style="cursor: default;"></div>').text(data)
            );

            $.each(data, function (ind, val) {

                resultContainer.append(
                    $('<div class="result" data-flow-index="' + ind + '" data-flow-id="' + val.id + '"></div>').text(val.title)
                );

            });

            $('.result').off('flowshare.click').on('click.flowshare', function () {

                let flowData = searchResultData[$(this).attr('data-flow-index')];
                let flowID = $(this).attr('data-flow-id');

                displayFullFlowData(flowData, flowID);

            })

        }

    }

    // ----- GLOBAL SEARCH -----

    $('#search-box').on('submit', function () {     // starts global search (submit form)
        globalSearch($('#search-txt').val());
    });

    $('#search-btn').on('click', function () {     // starts global search (search button pressed)
        globalSearch($('#search-txt').val());
    });

    function globalSearch(str) {

        if (str.match(/^[ ]*$/)) return;

        searchFilters.search = str;

        let searchTags = new URLSearchParams();
        $.each(searchFilters, function (key, value) {
            searchTags.append(key, value);
        });
        window.location.search = searchTags;

    }

    function flowSearchBackArrowPress() {   // when back arrow pressed on search list
        $('#flow-search-back-arrow').off('click.flowshare').on('click.flowshare', function () {
            applyFilters(true);
        });
    }


    // ---------- ACCOUNT MANAGEMENT ----------

    // todo: check token

    $('#header-account').on('click.flowshare', function () {

        // redirect on account page

        let loc = window.location.href;

        if (loc.match(/\/home\/.*/))
            window.location.href = loc.replace(/home\/.*/, '') + 'account/';
        else
            window.location.href = loc.split('/').slice(0, -1).join('/') + '/account/';

    });


    // ---------- LOAD FILTERS ----------

    let searchFilters = {};
    let defaultFilterValues = {
        sort: {
            default: 'new',
            display: true,
            displayType: 'filter',
            type: 'string'
        },
        id: {
            default: undefined,
            display: false,
            type: 'int'
        },
        search: {
            default: undefined,
            display: true,
            displayType: 'search',
            type: 'string'
        }
    };

    let searchTags = new URLSearchParams(window.location.search);

    let responseDiv = $('.response');

    $.each(defaultFilterValues, function (filterName, filterData) {    // for each possible filters

        let tag = searchTags.get(filterName) || filterData.default;  // getting actual value or set the default one
        let result;

        if (filterData.display) {    // if the value can be displayed

            result = displayFilters(filterName, tag, filterData.displayType);   // tries to display the value
            if (!result) displayFilters(filterName, filterData.default, filterData.displayType);    // if value wasn't displayed then display the default one

        } else result = true;

        if (filterData.default !== tag && result) searchFilters[filterName] = tag;    // if not default then value put it in filters list
    });


    function displayFilters(name, value, displayType) {  // tries to display the filter
        let result = false;

        if (displayType === 'filter') {

            responseDiv.each(function () {
                if ($(this).attr('data-filter-value') !== value) return;  // if wrong div
                $(this).parent().children('.response').css('backgroundColor', 'transparent');   // removing color of other fibers
                $(this).css('backgroundColor', '#fdcb6e');  // setting color of selection
                result = true;
            });

        } else if (displayType === 'search') {
            $('#search-txt').val(value);
            result = true;
        }

        return result;
    }

    responseDiv.css('transition', '.4s');    // activating animation (disabled for fastest loading display)


    // ---------- FILTER SELECTION ----------

    // ----- FILTERS STYLE -----

    let isFilterExtended = true;
    let allowFilterExtend = $(window).width() < 1000;

    if ($(window).width() < 1000) $('#nav-arrow').show();

    $('nav .title').click(function () {
        extentFilter(isFilterExtended);
        isFilterExtended = !isFilterExtended;
    });

    function filterWindowResize() {
        if ($(window).width() < 1000) {
            extentFilter(true);
            allowFilterExtend = true;
            $('#nav-arrow').show()
        } else {
            extentFilter(false);
            allowFilterExtend = false;
            $('#nav-arrow').hide()
        }
        isFilterExtended = $('nav').width() < 100;
    }

    function extentFilter(extend) {
        if (!allowFilterExtend) return;
        if (extend) {
            $('nav').css('height', '60px');
            $('#nav-arrow').removeClass('active');
        } else {
            $('nav').css('height', '310px');
            $('#nav-arrow').addClass('active');
        }
    }

    $('.filter').on('click', '.response', function () {
        let sel = $(this);
        sel.parent().children('.response').css('backgroundColor', 'transparent');   // removing color of other fibers
        sel.css('backgroundColor', '#fdcb6e');  // setting color of selection

        // ----- MANAGE FILTERS -----

        let filterName = sel.parent().attr('data-filter-name');
        let filterValue = sel.attr('data-filter-value');
        let isDefault = defaultFilterValues[filterName].default === filterValue;

        if (isDefault) delete searchFilters[filterName];
        else searchFilters[filterName] = filterValue;

    });

    // ----- APPLY FILTERS -----

    $('#apply-filters').click(function () {
        applyFilters(true);
    });

    function applyFilters(reload) {
        let searchTags = new URLSearchParams();
        delete searchFilters.search;
        $.each(searchFilters, function (key, values) {
            searchTags.append(key, values);
        });
        if (reload)
            window.location.search = searchTags;
        else
            if (searchTags.toString() === '')
                history.pushState({}, '', './');
            else
                history.pushState({}, '', '?' + searchTags.toString());

    }


    // ---------- FLOWS BROWSER ----------

    let flowBrowserOffset = 0;
    let flowBrowserFlows = [];

    if (!searchFilters.search)
        queryTopFlows(searchFilters.sort);
    else
        querySearchFlow(searchFilters.search);

    let flowsRequestData;
    let flowContainerList = $('#flow-list-container');


    function queryTopFlows(topRated) {

        let data = {offset: flowBrowserOffset};

        if (topRated) data['rated'] = 1;

        $.ajax({
            type: 'GET',
            url: flowshareURLs.api + 'flows.php',
            data: data,
            timeout: 5000,
            success: function (data) {

                if (decodeBrowserRequestData(data))
                    data = decodeBrowserRequestData(data);
                else
                    return;

                flowBrowserFlows = flowBrowserFlows.concat(data);
                displayFlowsList(data);

            },
            error: function () {
                $('#flows-loading').html('Error when getting flows list: AJAX error<br>Please reload page or contact the site administrator.');
            }
        })
    }

    function querySearchFlow(str) {

        $.ajax({
            type: 'GET',
            url: flowshareURLs.api + 'search.php',
            data: {
                text: str,
                offset: flowBrowserOffset
            },
            timeout: 5000,
            success: function (data) {

                if (decodeBrowserRequestData(data))
                    data = decodeBrowserRequestData(data);
                else
                    return;

                flowBrowserFlows = flowBrowserFlows.concat(data);
                displayFlowsList(data, 'result(s)</span> for ' + str, true, true);

            },
            error: function () {
                $('#flows-loading').html('Error when getting flows list: AJAX error<br>Please reload page or contact the site administrator.');
            }
        });

    }

    function decodeBrowserRequestData(data) {

        try {
            data = JSON.parse(data);
        } catch (e) {
            $('#flows-loading').html('JSON Parse error<br>Error: <br>' + e + '<br>Response body:<br>' + data);
            return false;
        }

        if (data.error) {
            flowContainerList.prepend('<i class="fas fa-chevron-circle-left back-arrow" id="flow-search-back-arrow" style="top: 5px; left: 5px"></i>');
            flowSearchBackArrowPress();
            $('#flows-loading').html('Error: ' + data.error);
            return false;
        }

        return data;

    }

    function displayFlowsList(data1, header, showResultsCount, showBackButton) {

        let data = flowBrowserFlows;

        flowsRequestData = data;

        flowContainerList.text('');

        if (header) {

            let resultCount = showResultsCount ? data.length + ' ' : '';
            let backButton = showBackButton ? '<i class="fas fa-chevron-circle-left back-arrow" id="flow-search-back-arrow"></i>' : '';

            flowContainerList.append(
                $('<div class="header">' + backButton + resultCount + header + '</div><hr>')
            );

            if (showBackButton) flowSearchBackArrowPress();

        }

        $.each(data, function (index, value) {

            let flowContainer = $('<div class="flow-container"></div>')
                .attr('data-flow-id', value['id'])
                .attr('data-flow-index', index);

            flowContainer.append(
                $('<div class="flow-title"></div>').text(value['title'])
            );
            flowContainer.append(
                $('<div class="flow-author"></div>').text(value['user'])
            );
            flowContainer.append(
                $('<div class="flow-description"></div>').text(value['description'])
            );
            flowContainer.append(
                $('<div class="flow-downloads"></div>')
                    .append($('<i class="fas fa-download"></i>')
                        .append($('<span class="number-container"></span>')
                            .text(value['downloads'])
                        )
                    )
            );
            flowContainer.append(
                $('<div class="flow-rating"></div>')
                    .append($('<i class="far fa-star"></i>')
                        .append($('<span class="number-container"></span>')
                            .text(value['ratings'])
                        )
                    )
            );

            flowContainerList.append(flowContainer);
            $('.flow-container:odd').css('backgroundColor', '#E5E5E5');

            triggerFlowContainerClick();

        });

    }


    // ----- Scroll updates -----

    let scrollingUpdate = false;

    body.on('scroll', function () {

        let remainScroll = body.prop('scrollHeight') - body.height() - body.scrollTop();

        if (remainScroll < 200 && !scrollingUpdate) {

            flowBrowserOffset = 15;

            if (!searchFilters.search)
                queryTopFlows(searchFilters.sort);
            else
                querySearchFlow(searchFilters.search);

            scrollingUpdate = true;

        }

    });


    // ---------- DISPLAY FULL FLOW DATA ----------


    function triggerFlowContainerClick() {

        $('.flow-container').off('click.flowshare').on('click.flowshare', function () {

            let flowIndex = $(this).attr('data-flow-index');
            let flowID = $(this).attr('data-flow-id');
            let flowData = flowsRequestData[flowIndex];

            displayFullFlowData(flowData, flowID);

        });

    }


    function displayFullFlowData(flowData, flowID) {

        $('#flow-data')
            .html('')
            .append(
                $('<i class="fas fa-chevron-circle-left back-arrow" id="full-flow-data-back-arrow"></i>')
            )
            .append(
                $('<div class="flow-title"></div>').text(flowData['title'])
            )
            .append(
                $('<div class="flow-author"></div>').text(flowData['user'])
            )
            .append(
                $('<div class="flow-description"></div>').text(flowData['description'])
            )
            .append(
                $('<div id="flow-data-bar" style="margin-bottom: 20px"></div>')
                    .append(
                        $('<div></div>')
                            .append(
                                $('<i class="fas fa-download"></i>')
                                    .append(
                                        $('<span class="number-container"></span>').text(flowData['downloads'])
                                    )
                            )
                    )
                    .append(
                        $('<div></div>')
                            .append(
                                $('<i class="far fa-star"></i>')
                                    .append(
                                        $('<span class="number-container"></span>').text(flowData['ratings'])
                                    )
                            )
                    )
                    .append(
                        $('<div id="download-button"><i class="fas fa-file-download"></i>  Download</div>')
                    )
                    .append(
                        $('<div style="float: none" id="review-button"><i class="fas fa-user-plus"></i>  Add review</div>')
                    )
            )
            .css('opacity', 1)
            .css('pointerEvents', 'all');


        // manage download button

        $('#download-button').off('click.flowshare').on('click.flowshare', function () {
            downloadFlow(flowID, flowData['title']);
        });
        flowDataWindowResize($(window).width());

        // manage flow list

        flowContainerList.css('opacity', 0);
        if ($(window).width() < 1000) $('nav').css('opacity', 0);
        body.css('pointerEvents', 'none');
        $('header').css('pointerEvents', 'all');

        flowBackArrowClick();

        // query flow ratings

        $.ajax({
            url: flowshareURLs.api + 'reviews.php?view&id=' + flowID,
            method: 'GET',
            timeout: 4000,
            success: function (data) {
                displayFlowReviews(data);
            },
            error: function (response) {
                if (response.status === 404) return;    // if no ratings
                $('#flow-data').append(
                    $('\'<div class="rating-container">Error when getting flow reviews : <br>AJAX error</div>')
                );
            }

        });

        // update url

        searchFilters['id'] = flowID;
        applyFilters(false)

    }

    function flowBackArrowClick() {
        $('#full-flow-data-back-arrow')
            .off('click.flowshare')
            .on('click.flowshare', function () {
                triggerFlowContainerClick();
                $('#flow-list-container, nav')
                    .css('opacity', 1);
                body
                    .css('pointerEvents', 'all');
                $('#flow-data')
                    .css('opacity', 0)
                    .css('pointerEvents', 'none')
                    .html('');
                delete searchFilters.id;
                applyFilters(false);
            });

    }

    function flowDataWindowResize(windowWidth) {

        // fix margin bug with review button

        let reviewButton = $('#review-button');

        if (windowWidth < 900 || (windowWidth > 1000 && windowWidth < 1350))
            reviewButton.css('left', '6%');
        else
            reviewButton.css('left', '0');


    }

    function displayFlowReviews(data) {

        if (data === null) return;

        let flowData = $('#flow-data');

        try {
            data = JSON.parse(data);
        } catch (e) {
            flowData.append(
                $('<div class="rating-container">JSON Parsing error<br>Error: <br>' + e + '<br>Response body:<br>' + data + '</div>')
            );
        }

        if (body.css('pointerEvents') === 'none' && data.length > 0) {

            flowData.append(
                $('<div style="position: relative; margin: 20px; font-size: 25px; font-weight: 600">Ratings</div>')
            );

            $.each(data, function (index, value) {

                flowData.append(
                    $('<div class="rating-container"></div>')
                        .append(
                            $('<div class="rating-title"></div>')
                                .text(value['username'])
                                .append(
                                    (value['isedited'] === '1' ? ' <span style="opacity: .5; font-weight: lighter; margin-left: 10px">(edited)</span>' : '')
                                )
                        )
                        .append(
                            $('<div class="rating-body"></div>')
                                .text(value['comment'])
                        )
                )

            });

            $('.rating-container:even').css('backgroundColor', '#E5E5E5');

        }

    }

    function downloadFlow(id, title) {
        $.ajax({
            method: 'GET',
            url: flowshareURLs.api + 'flows.php/id/' + id + '?data&base64',
            timeout: 10000,
            success: function (data) {
                let element = document.createElement('a');
                element.setAttribute('href', 'data:application/octet-stream;charset=utf-8;base64,' + data);
                element.setAttribute('download', title + '.flo');

                element.style.display = 'none';
                document.body.appendChild(element);

                element.click();

                document.body.removeChild(element);
            },
            error: function () {
                alert('Download error');
            }
        })
    }

});
