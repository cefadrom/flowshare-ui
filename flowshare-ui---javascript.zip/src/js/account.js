$(function () {

    // ---------- GLOBAL ----------

    let windowWidth = $(window).width();

    $(window).resize(function () {

        windowWidth = $(this).width();

        categoryWindowResize();

    });


    // ---------- HEADER ----------

    $('#header-home').on('click.flowshare', function () {

        // redirect on home page
        window.location.href = window.location.href.replace(/account\/.*/, 'home/');

    });


    // ---------- CATEGORIES ----------

    let allowChoseCategory = true;

    let categoryDiv = $('.category');

    $('.category:first').css('backgroundColor', '#fdcb6e');

    categoryDiv.on('click.flowshare', function () {

        if (allowChoseCategory) {

            $('.category').css('backgroundColor', 'transparent');
            $(this).css('backgroundColor', '#fdcb6e');

            let category = $(this).attr('data-nav-value');
            setCategory(category);

        }

    });

    function setCategory(name) {

        $('#content').html('');
        $(name).clone().css('display', 'block').appendTo('#content');

        if (name === '#content-account') {
            let data = Cookies.getJSON('account');
            $('#content-account .title:first').text('Connected as ' + data['username']);
        }

        if (name === '#content-upload')
            displayUploadFlowForm();

        if (name === '#content-daily')
            displayDailyShareCoins();

    }

    setTimeout(function () {
        categoryDiv.css('transition', '.4s');
    }, 400);


    // ----- CATEGORY STYLE -----

    let isNavExtended = true;
    let allowNavExtend = windowWidth < 1000;

    if (windowWidth < 1000) $('#nav-arrow').show();

    $('nav .title').click(function () {
        extentNav(isNavExtended);
        isNavExtended = !isNavExtended;
    });

    function categoryWindowResize() {
        if (windowWidth < 1000) {
            extentNav(true);
            allowNavExtend = true;
            $('#nav-arrow').show()
        } else {
            extentNav(false);
            allowNavExtend = false;
            $('#nav-arrow').hide()
        }
        isNavExtended = $('nav').height() < 100;
    }

    function extentNav(extend) {
        if (!allowNavExtend) return;
        if (extend) {
            $('nav').css('height', '60px');
            $('#nav-arrow').removeClass('active');
        } else {
            $('nav').css('height', '310px');
            $('#nav-arrow').addClass('active');
        }
    }


    // ---------- ACCOUNT PART ----------

    let contentDiv = $('#content');

    contentDiv.html('');

    if (!Cookies.get('account'))
        displayLoginForm();
    else
        displayAccountData();

    // ----- ACCOUNT DATA -----

    function displayAccountData(data) {

        contentDiv.html('<div id="loading-message">Loading data...</div>');

        categoryDiv.css({
            cursor: 'pointer',
            opacity: '1'
        });
        allowChoseCategory = true;

        if (data) return displayContent(data);

        let account = Cookies.getJSON('account');

        $.ajax({
            method: 'GET',
            url: 'https://rasphost.com/flowshare/account.php',
            data: {token: account['token']},
            success: function (data) {

                try {
                    data = JSON.parse(data);
                } catch (e) {
                    $('#loading-message').text('AJAX error: ' + e);
                }

                if (data['error']) {
                    return displayLoginForm(data['error']);
                }

                displayContent(data);

            },
            error: function () {
                $('#loading-message').text('AJAX error. Please reload the page.');
            }
        });

        function displayContent(data) {

            contentDiv.html('');

            let cookieExpires = Cookies.getJSON('account').expires = 0 ? undefined : {expires: Cookies.getJSON('account').expires};
            let newCookie = Object.assign(
                Cookies.getJSON('account'),
                {
                    email: data['email'],
                    username: data['username']
                }
            );
            Cookies.set('account', newCookie, cookieExpires);

            $('#content-account').clone().appendTo(contentDiv).show();
            $('#content-account .title:first').html('Connected as ' + data['username'] + '<br>' + data['coins'] + ' sharecoins');

            $('#account-logout').on('click.flowshare', function () {
                Cookies.remove('account');
                displayLoginForm(undefined, data['email']);
            })

        }

    }

    // ----- LOGIN -----

    function displayLoginForm(error, email) {

        contentDiv.html('');

        categoryDiv.css({
            cursor: 'not-allowed',
            opacity: '.6'
        });

        allowChoseCategory = false;
        $('#content-login').clone().appendTo(contentDiv).show();

        let mask = $('#content-login .mask:first');
        $('#login-mail').focus();

        if (error) displayError(error);

        if (!email && Cookies.getJSON('account')) email = Cookies.getJSON('account')['email'];

        if (email) {
            $('#login-mail').val(email);
            $('#login-password').focus();
        } else {
            $('#login-mail').focus();
        }

        $('#content-login').on('submit', function () {

            mask.fadeIn();

            $.ajax({
                method: 'POST',
                url: 'https://rasphost.com/flowshare/login.php',
                data: {
                    email: $('#login-mail').val(),
                    password: $('#login-password').val()
                },
                success: function (data) {
                    loginResult(data);
                },
                error: function () {
                    mask.fadeOut();
                    displayError('AJAX error: please try later or contact the administrator');
                }
            })

        });

        $('#content-login .additional-button').on('click.flowshare', function () {

            if ($(this).attr('data-ref') === 'token')
                displayTokenLoginForm();
            else
                displayRegisterForm();

        });

        function loginResult(data) {

            mask.fadeOut();

            try {
                data = JSON.parse(data);
            } catch (e) {
                return displayError('Error: ' + data);
            }

            if (data['error']) return displayError(data['error']);
            if (data['response'] !== 'OK') return displayError('Error: ' + JSON.stringify(data));

            let args;
            if ($('#content-login #login-remember:checked').length)
                args = {expires: 365};

            Cookies.set('account', {
                token: data['token'],
                expires: args ? 365 : 0
            }, args);

            displayAccountData();

        }

        function displayError(msg) {
            $('.error-msg:first').text(msg);
            $('#login-mail').focus();
            return $('#login-password').val('');
        }

    }

    // ----- LOGIN WITH TOKEN -----

    function displayTokenLoginForm() {

        contentDiv.html('');

        categoryDiv.css({
            cursor: 'not-allowed',
            opacity: '.6'
        });

        allowChoseCategory = false;
        $('#content-login-token').clone().appendTo(contentDiv).show();

        $('#login-token').focus();
        let mask = $('#content-login-token .mask');

        $('#content-login-token').on('submit', function () {

            mask.fadeIn();

            $.ajax({
                method: 'GET',
                url: 'https://rasphost.com/flowshare/account.php',
                data: {
                    token: $('#login-token').val()
                },
                timeout: 5000,
                success: function (data) {
                    mask.fadeOut();
                    ajaxResult(data);
                },
                error: function () {
                    mask.fadeOut();
                    displayError('AJAX error: please try later or contact the administrator');
                }
            })

        });

        $('#content-login-token .additional-button').on('click.flowshare', function () {
            displayLoginForm();
        });

        function ajaxResult(data) {

            try {
                data = JSON.parse(data);
            } catch (e) {
                return displayError('JSON parse error, ' + data);
            }

            if (data['error'])
                return displayError(data['error']);

            if (!(data['username']))
                return displayError('Unknown error, please try again');

            let args;
            if ($('#content-login-token #token-remember:checked').length > 0)
                args = {expires: 365};

            console.log(args);

            Cookies.set('account', {
                token: $('#login-token').val(),
                username: data['username'],
                expires: args ? 365 : 0
            }, args);

            displayAccountData(data);

        }

        function displayError(msg) {
            $('.error-msg:first').text(msg);
            $('#login-token').focus();
        }

    }

    // ----- REGISTER -----

    function displayRegisterForm() {

        contentDiv.html('');

        categoryDiv.css({
            cursor: 'not-allowed',
            opacity: '.6'
        });

        allowChoseCategory = false;
        $('#content-register').clone().appendTo(contentDiv).show();

        $('#register-email').focus();
        let mask = $('#content-register .mask');

        //todo: finish register part
        alert('This functionality is WIP. Please create an account with the flowshare flow.');

        $('#content-register').on('submit', function () {

            let requestData = {
                email: $('#register-email').val(),
                password: $('#register-password-1').val(),
                username: $('#register-username').val()
            };

            if (requestData.password !== $('#register-password-2').val())   // if password != password confirmation
                return displayError('The two passwords must be identical.');

            //     mask.fadeIn();
            //
            //     $.ajax({
            //         method: 'POST',
            //         url: 'https://rasphost.com/flowshare/register.php',
            //         data: requestData,
            //         timeout: 5000,
            //         success: function (data) {
            //             mask.fadeOut();
            //         },
            //         error: function () {
            //             mask.fadeOut();
            //         }
            //     })

        });

        $('#content-register .additional-button').on('click.flowshare', function () {
            displayLoginForm();
        });

        function displayError(msg) {
            $('.error-msg:first').text(msg);
            $('#register-password-1, #register-password-2').val('');
            $('#register-email').focus();
        }

    }


    // ---------- UPLOAD FLOW ----------

    function displayUploadFlowForm() {

        let flowData,
            uploadTitle = $('#upload-title'),
            uploadDescription = $('#upload-description'),
            uploadFlowInput = $('#upload-flow'),
            mask = $('#content-upload .mask'),
            errorMsg = $('#content-upload .error-msg');

        uploadFlowInput.on('change', function () {

            let fr = new FileReader();
            let file = uploadFlowInput.prop('files')[0];
            fr.onload = function () {
                flowData = fr.result.split(';base64,')[1];
                if (uploadTitle.val() === '')
                    uploadTitle.val(file.name.split('.flo')[0])
            };
            fr.readAsDataURL(file);

        });

        $('#content-upload').on('submit', function () {
            uploadFlow(
                uploadTitle.val(),
                uploadDescription.val(),
                flowData
            )
        });

        function uploadFlow(title, description, data) {

            let token = Cookies.getJSON('account').token;
            mask.fadeIn();

            $.ajax({
                method: 'POST',
                url: 'https://rasphost.com/flowshare/flows.php',
                data: {
                    title: title,
                    description: description,
                    data: data,
                    base64: '',
                    token: token,
                    post: ''
                },
                timeout: 10000,
                success: function (data) {

                    mask.fadeOut();

                    try {
                        data = JSON.parse(data);
                    } catch (e) {
                        return errorMsg.text('JSON parse error, response: ' + data);
                    }

                    loadResponse(data);

                },
                error: function () {
                    mask.fadeOut();
                    errorMsg.text('AJAX error, please try again.');
                }
            });

            function loadResponse(data) {

                if (data.error) return errorMsg.text(data.error);

                $('#content').html(
                    '<div id="loading-message">Response: ' + data.response + (data['id'] ? ', flow id: ' + data.id : '') + '</div>'
                )

            }

        }

    }


    // ---------- GET DAILY SHARECOINS ----------

    function displayDailyShareCoins() {

        let dailyButton = $('#daily-button');
        let mask = $('#content-daily .mask');
        let errorMsg = $('#content-daily .error-msg').css('padding-top', '10px');

        dailyButton.on('click', function () {

            let token = Cookies.getJSON('account').token;
            mask.fadeIn();

            $.ajax({
                method: 'POST',
                url: 'https://rasphost.com/flowshare/daily.php',
                data: {
                    token: token
                },
                timeout: 5000,
                success: function (data) {

                    mask.fadeOut();

                    try {
                        data = JSON.parse(data);
                    } catch (e) {
                        return errorMsg.text('JSON parse error, response: ' + data)
                    }

                    if (data['error'])
                        return errorMsg
                            .css('color', 'red')
                            .text(data.error);

                    errorMsg
                        .css('color', '#3bce38')
                        .text(data.response)

                },
                error: function () {

                    mask.fadeOut();
                    errorMsg.text('AJAX error. Please try later');

                }
            })

        })

    }

});
